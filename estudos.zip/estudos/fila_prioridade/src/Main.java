public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        Nodo d = new Nodo (5, 3);
        System.out.println("elemento: "+ d.getPrioridade());
        System.out.println("prioridade: " + d.getElemento());

        FPListaNaoOrdenada listaprioridade = new FPListaNaoOrdenada();
        Nodo d2 = new Nodo (7, 1);
        Nodo d3 = new Nodo (3, 10);
        Nodo d4 = new Nodo (2, 4);
        Nodo d5 = new Nodo (5, 7);

        listaprioridade.add(d);
        listaprioridade.add(d2);
        listaprioridade.add(d3);
        listaprioridade.add(d4);
        listaprioridade.add(d5);

        System.out.println(listaprioridade.toString());

        System.out.println(listaprioridade.obter()); // deve ser 3, 10
        System.out.println(listaprioridade.remover()); // remove o de cima
        System.out.println(listaprioridade.obter()); // deve aperecer 5,7

        //testando heaps

        System.out.println("---testando heaps---");

        MaxHeap MH = new MaxHeap();
        

        System.out.println("deve ser 0 o tamanho"+ MH.tamanho());

        //adicionando um elemento

        MH.add(1,1);

        System.out.println("deve ser 1 o tamanho: "+ MH.tamanho());

        //obtendo o elemento 9

        MH.add(9, 4);

        System.out.println("elemento 9: "+ MH.obter());

        //testando operações

        //testando pai, esquerda e direita;



        MH.add(5, 2);
        MH.add(1, 7);
        MH.add(20, 8);
        MH.add(13, 10);
        MH.add(15, 3);

        int quantidade = MH.tamanho();
         

        System.out.println("quantidade: "+ quantidade);

        //testando pai do 7° elemento

        System.out.println("o pai do 7° elemento é: "+ MH.buscarPai(7).toString());

        System.out.println("o filho direito do 3° elemento é: "+ MH.buscarDireito(3).toString());

        System.out.println("o filho esquerdo do 3° elemento é: "+ MH.buscarEsquerdo(3).toString());

        

    }
}
public class Nodo{

    private int elemento;
    private int prioridade;

    public Nodo(int elemento, int prioridade){
        setPrioridade(prioridade);
        setElemento(elemento);
    }

    public int getElemento(){
        return this.elemento;
    }

    public int getPrioridade(){
        return this.prioridade;
    }

    public void setElemento(int elemento){

        this.elemento=elemento;
    }

    public void setPrioridade(int prioridade){
        this.prioridade=prioridade;
    }

    @Override
    public String toString(){
        return "{Nodo: elemento = " + getElemento() + " prioridade = " + getPrioridade() + "}";
    }

}
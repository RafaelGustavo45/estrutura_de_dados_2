import java.util.Arrays;

public class MaxHeap implements FilaDePrioridade{
    private Nodo heap[];
    private int tamanho;

    public MaxHeap(){
        heap = new Nodo[8];
    }

    @Override
    public int tamanho(){
        return tamanho;

    }

    @Override
    public void add(int elemento, int prioridade){

        if (tamanho == heap.length) {
            throw new RuntimeException("Heap está cheio");

        }
    heap[tamanho] = new Nodo(elemento, prioridade);
    corrigirDeBaixoParaCima(tamanho);
    tamanho++;
    }

    public int pai(int posicao){
        posicao--;
        return (int)Math.floor(posicao/2.0);
    }

    public int esquerda(int posicao){
        posicao--;
        return 2*posicao;

    }

    public int direita(int posicao){
        posicao--;
        return (2* posicao) +1;
    }

    public Nodo buscarPai(int posicao){
       int posicao2 = pai(posicao);
       return heap[posicao2];
    }

    public Nodo buscarEsquerdo(int posicao){
        int posicao2 = esquerda(posicao);
        return heap[posicao2];
    }

    public Nodo buscarDireito(int posicao){
        int posicao2 = direita(posicao);
        return heap[posicao2];
    }

    public void corrigirDeBaixoParaCima(int posicao){
        if (posicao == 0) return;

        if (heap[pai(posicao)].getPrioridade() < heap[posicao].getPrioridade()){
            //troca
            var temp=heap[pai(posicao)];
            heap [pai(posicao)] = heap[posicao];
            heap [posicao] = temp;
            //chamada recursiva wtf

            corrigirDeBaixoParaCima(pai(posicao));
        }
    }

    @Override
    public int remover(){
        if (tamanho < 1){
            throw new RuntimeException("heap está vazio");
        }
        Nodo removido = heap[0];
        heap[0] = heap[tamanho-1];
        heap[tamanho-1] = null;
        tamanho--; // reduz em 1
        corrigirDeCimaParaBaixo(0);
        return removido.getElemento();
    }

    private void corrigirDeCimaParaBaixo(int posicao){
        if(posicao >= tamanho){
            return;
        }
        int maior = posicao;
        if(esquerda(posicao) < tamanho && heap[esquerda(posicao)].getPrioridade() > heap[posicao].getPrioridade()){
            maior = esquerda(posicao);
        }
        if (direita(posicao) < tamanho && heap[direita(posicao)].getPrioridade() > heap[posicao].getPrioridade()){
            maior = direita(posicao);
        }
        if (maior != posicao){
            //troca
            var temp = heap[maior];
            heap[maior] = heap[posicao];
            heap[posicao] = temp;

            //chamada recursiva
            corrigirDeCimaParaBaixo(maior);
        }
    }

    @Override
    public int obter(){
       if (tamanho < 1){
        throw new RuntimeException("heap está vazio");
       }
       return heap[0].getElemento();
    }

    @Override
    public String toString(){
       return Arrays.toString(heap);
    }







}

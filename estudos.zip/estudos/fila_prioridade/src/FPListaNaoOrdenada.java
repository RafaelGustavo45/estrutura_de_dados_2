import java.util.ArrayList;
import java.util.List;

public class FPListaNaoOrdenada implements FilaDePrioridade{
    private List<Nodo> lista;

    public FPListaNaoOrdenada(){
        lista = new ArrayList<>();
    }

    @Override
    public int tamanho(){
        return lista.size();
    }

    @Override
    public void add(int elemento, int prioridade){
        Nodo nodo = new Nodo(elemento,prioridade);
        lista.add(nodo);
    }

    public void add(Nodo d){
        lista.add(d);
    }

    @Override
    public int remover(){
        if  (tamanho() < 1){
            throw new RuntimeException("FP está Vazia");
        }
        int maior=0;
        //percorrendo lista
        for (int i = 1; i <lista.size(); i++){
           if(lista.get(i).getPrioridade() > lista.get(maior).getPrioridade()){
            maior=i;
           }

        }
        Nodo nodo = lista.remove(maior);
        return nodo.getElemento();
    }

    @Override
    public int obter(){
        if (tamanho() < 1){
            throw new RuntimeException("FP está vazia");
        }
        Nodo maior = lista.get(0);

        for (Nodo n: lista){
            if(n.getPrioridade() > maior.getPrioridade()){
                maior=n;
            }
        }
        return maior.getElemento();
    }

    @Override
    public String toString(){
        StringBuffer montando = new StringBuffer();
        montando.append("{ FPListaNaoOrdenada: ");
        for (Nodo n: lista) {
            montando.append(n.toString());
            montando.append(" & ");
        }
        montando.append("}");

        return montando.toString();
    }




}

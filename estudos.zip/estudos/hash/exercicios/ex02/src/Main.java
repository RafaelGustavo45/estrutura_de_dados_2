import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Main {

    public static void main(String[] args) {
        TabelaHash tb = new TabelaHash();
        

        
    }

}

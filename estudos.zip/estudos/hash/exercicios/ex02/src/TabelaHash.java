import java.util.ArrayList;

public class TabelaHash<T> {

    ArrayList valores = new ArrayList();
    ArrayList chaves = new ArrayList();

    public TabelaHash(){

        this.valores = new ArrayList();
        this.chaves = new ArrayList();


    }

    public void adicionar(Class<T> c, Class<T> v){
        this.chaves.add(c);
        this.valores.add(v);

    }

    public void remover(Class<T> c){
        int index = this.chaves.indexOf(c);
        this.chaves.remove(index);
        this.valores.remove(index);
    }

    public Class<T> obter(Class<T> c){
        int index = this.chaves.indexOf(c);
        return (Class<T>) this.valores.get(index);
    }

    public boolean contemChave(Class<T> c){
        return this.chaves.contains(c);
    }

    public int tamanho(){
        return this.chaves.size();
    }

    public boolean estaVazio(){
        return this.chaves.isEmpty();
    }
    









}
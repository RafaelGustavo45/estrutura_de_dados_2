public class TabelaHash implements Mapa{
    private int tamanho;
    private int[] valores;
    private int limite;


    public TabelaHash(){
        this.tamanho=0;
        this.limite=100;
        this.valores = new int[this.limite];

    }

    @Override
    public void adicionar(int chave, int valor){
        if(chave > this.limite){
          throw new RuntimeException("chave maior doque o limite");
       } else{
          this.valores[chave] = valor;
         }
    }

    public boolean VerificarLimite(int chave){
        if(chave < this.limite){
            return false; // fora do limite
        } else{
            return true; // dentro do limite
        }
    }

    @Override
    public int remover(int chave){
      int removido = this.valores[chave];
      this.valores[chave] = 0;
      return removido;
    }

    @Override
    public int obter(int chave){
        return this.valores[chave];
    }

    @Override
    public int tamanho(){
        /*int q=0;
        for (i= 0; i< limite; i++){
            if (this.valores[i] =! 0){
               q++;
            } else{

            }
        }
        return q; */
        return this.limite;
    }

    @Override
    public boolean contemChave(int chave){
        if (this.valores[chave] == 0){
           return false;
        } else{
            return true;
        }
    }

    @Override
    public boolean estaVazio(){
        for (int c : this.valores) {
            if (c != 0){
                return false;
            }
            
        }
        return true;
    }


}
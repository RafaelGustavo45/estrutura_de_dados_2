import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Main {

    public static void main(String[] args) {
        TabelaHash tb = new TabelaHash();
        tb.adicionar(50, 90);
        tb.adicionar(10, 140);

        tb.adicionar(15, 87);


        System.out.println(tb.contemChave(15));

        System.out.println(tb.contemChave(33));

        System.out.println(tb.remover(50));

        
    }

}

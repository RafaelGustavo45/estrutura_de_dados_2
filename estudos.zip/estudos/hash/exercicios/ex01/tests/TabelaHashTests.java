import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TabelaHashTests {

    @Test
    public void testNovaTabelaHash(){
        Mapa m = new TabelaHash();
        boolean vazio = m.estaVazio();
        int tamanho = m.tamanho();
        Assertions.assertEquals(true
                , vazio,"A tabela deve estar vazio.");
        Assertions.assertEquals(0
                , tamanho,"A tabela deve ter o tamanho zero.");
    }

    @Test
    public void testNovaTabelaHashComTamanho1(){
        Mapa m = new TabelaHash();
        m.adicionar(1,10);
        boolean vazio = m.estaVazio();
        int tamanho = m.tamanho();
        Assertions.assertEquals(false
                , vazio,"A tabela não deve estar vazio.");
        Assertions.assertEquals(1
                , tamanho,"A tabela deve ter o tamanho 1.");
    }

    @Test
    public void testObterOElementoDeUmaTabelaComTamanho1(){
        Mapa m = new TabelaHash();
        m.adicionar(1,10);
        boolean existeChave = m.contemChave(1);
        int elemento = m.obter(1);
        Assertions.assertEquals(true
                , existeChave,"A tabela deve conter a chave 1.");
        Assertions.assertEquals(10
                , elemento,"O elemento 10 deve estar associado a chave 1.");
    }

}
public class TabelaHash implements Mapa{

    private int tamanho;

    @Override
    public void adicionar(int chave, int valor) {
        tamanho++;
    }

    @Override
    public int remover(int chave) {
        return 0;
    }

    @Override
    public int obter(int chave) {
        return 0;
    }

    @Override
    public boolean contemChave(int chave) {
        return false;
    }

    @Override
    public int tamanho() {
        return tamanho;
    }

    @Override
    public boolean estaVazio() {
        return tamanho == 0;
    }
}

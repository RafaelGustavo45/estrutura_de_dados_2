public class TabelaHashException extends RuntimeException{
    public TabelaHashException(String msg){
        super(msg);
    }
}
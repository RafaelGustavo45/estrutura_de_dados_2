import java.util.ArrayList;

public class TabelaHash implements Mapa {
    private int tamanho;
    private ArrayList<Integer> elementos;
    private ArrayList<Integer> chaves;

    public TabelaHash() {
        tamanho = 0; // Inicializa tamanho como 0
        elementos = new ArrayList<>(); // Inicializa as listas
        chaves = new ArrayList<>();
    }

    @Override
    public int remover(int chave) {
        int pos = chaves.indexOf(chave);
        if (pos == -1) {
            //return -1;  Chave não encontrada
            throw new TabelaHashException("chave não encontrada");
        }
        int removido = elementos.get(pos);
        elementos.remove(pos);
        chaves.remove(pos);
        tamanho--;
        return removido; // Retorna a chave removida
    }

    // Outros métodos da interface Mapa...

    @Override
    public int obter(int chave){
        int pos = chaves.indexOf(chave);
        if (pos == -1) {
            //return -1;  Chave não encontrada
            throw new TabelaHashException("chave não encontrada");
        }
        return (int)elementos.get(pos);

    }
    @Override
    public void adicionar(int chave, int valor){
        chaves.add(chave);
        elementos.add(valor);
        tamanho++;
    }

    @Override
    public int tamanho(){
        return tamanho;
    }
    @Override
    public boolean contemChave(int chave){
        return chaves.contains(chave);
    }

    @Override
    public boolean estaVazio(){
        return tamanho==0;
    }


}

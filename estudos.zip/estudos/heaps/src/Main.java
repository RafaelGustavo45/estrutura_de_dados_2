public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");

        TabelaHash tb = new TabelaHash();
        
        tb.adicionar(30, 1);
        tb.adicionar(3, 5);
        tb.adicionar(9,7);
        tb.adicionar(14, 45);

        //testando

        System.out.println("contem chave 3?: "+ tb.contemChave(3));
        System.out.println("contem chave 6?: "+ tb.contemChave(6));

        System.out.println("buscando chave 9: "+ tb.obter(9));

        System.out.println("tamanho 4?: "+ tb.tamanho());

        System.out.println("buscando chave 17: "+ tb.obter(17)); // deve dar erro

 

    }
}